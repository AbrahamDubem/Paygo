package com.example.pay_go

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
